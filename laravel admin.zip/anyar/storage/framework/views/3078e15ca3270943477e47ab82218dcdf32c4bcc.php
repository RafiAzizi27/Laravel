<?php $__env->startSection('content'); ?>
<section class="main-section">
        <div class="content">
            <h1>Ubah Pembelian</h1>
            <hr>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><strong><?php echo e($error); ?></strong>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('pembelian.update', $datas->id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

            <div class="form-group">
                <label for="kd_barang">Nama Barang:</label>
                <input type="text" class="form-control" id="kd_barang" name="kd_barang" value="<?php echo e($datas->kd_barang); ?>">
            </div>
            <div class="form-group">
                <label for="jumlah">jumlah:</label>
                <input type="text" class="form-control" id="jumlah" name="jumlah" value="<?php echo e($datas->jumlah); ?>">
            </div>
            <div class="form-group">
                <label for="total_harga">Total Harga:</label>
                <input type="text" class="form-control" id="total_harga" name="total_harga" value="<?php echo e($datas->total_harga); ?>">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-md btn-primary">Submit</button>
                <button type="reset" class="btn btn-md btn-danger">Cancel</button>
            </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\anyar\resources\views/pembelian_edit.blade.php ENDPATH**/ ?>