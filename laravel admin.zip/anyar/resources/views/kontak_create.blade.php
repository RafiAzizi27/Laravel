@extends('template')
@section('content')

<section class="main-section">
<div class="content">
<div class="container">

    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg-7">
            <div class="p-5">
              
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Tambah Kontak !</h1>
              </div>

              @if($errors->any())
                <div class="alert alert-danger">
                    @foreach($errors->all() as $error)
                        <li><strong>{{ $error }}</strong>
                    @endforeach
            </div>
        @endif

              <form action="{{ route('kontak.store') }}" method="post">
            {{ csrf_field() }}
            <div class="form-group">
                <label for="nama">Nama:</label>
                <input type="text" class="form-control" id="usr" name="nama">
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>
            <div class="form-group">
                <label for="nohp">No Hp:</label>
                <input type="text" class="form-control" id="nohp" name="nohp">
            </div>
            <div class="form-group">
                <label for="alamat">Alamat:</label>
                <textarea class="form-control" id="alamat" name="alamat"></textarea>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-md btn-primary">Submit</button>
                <button type="reset" class="btn btn-md btn-danger">Cancel</button>
            </div>
        </form>
            </div>
          </div>
        </div>
      </div>
    </div>

            

</div>
</div>
</section>
@endsection
