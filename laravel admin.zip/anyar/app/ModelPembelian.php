<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelPembelian extends Model
{
    protected $table ="model_pembelians";
}
